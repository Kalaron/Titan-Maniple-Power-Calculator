﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Plasma Blastgun")
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Inferno Cannon")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Vulcan Megabolter")
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Turbo-Laser Destructor")
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warhound", New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode2, TreeNode3, TreeNode4})
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Volcano Cannon")
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Gatling Blaster")
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Triple-Barrel Turbo-Laser Destructor")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Melta Cannon")
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Powerfist")
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Melta-Chainfist")
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Power Galatine")
        Dim TreeNode13 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Vulcan Megabolter")
        Dim TreeNode14 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Plasma Blastgun")
        Dim TreeNode15 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Inferno Cannon")
        Dim TreeNode16 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Reaver", New System.Windows.Forms.TreeNode() {TreeNode6, TreeNode7, TreeNode8, TreeNode9, TreeNode10, TreeNode11, TreeNode12, TreeNode13, TreeNode14, TreeNode15})
        Dim TreeNode17 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Macro Gatling Blaster")
        Dim TreeNode18 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Belicosa Volcano Cannon")
        Dim TreeNode19 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Melta Cannon")
        Dim TreeNode20 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Triple-Barrel Turbo-Laser Destructor")
        Dim TreeNode21 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nemesis (Carapace) Quake Cannon")
        Dim TreeNode22 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nemesis (Carapace) Kallidan Linear Accelerator")
        Dim TreeNode23 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warbringer", New System.Windows.Forms.TreeNode() {TreeNode17, TreeNode18, TreeNode19, TreeNode20, TreeNode21, TreeNode22})
        Dim TreeNode24 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Macro Gatling Blaster")
        Dim TreeNode25 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Belicosa Volcano Cannon")
        Dim TreeNode26 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Mori Quake Cannon")
        Dim TreeNode27 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Plasma Immolator")
        Dim TreeNode28 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Apocalypse Missle Launcher")
        Dim TreeNode29 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Triple-Barrel Turbo-Laser Destructor")
        Dim TreeNode30 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warlord", New System.Windows.Forms.TreeNode() {TreeNode24, TreeNode25, TreeNode26, TreeNode27, TreeNode28, TreeNode29})
        Dim TreeNode31 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Plasma Annihilator")
        Dim TreeNode32 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Hellstorm Cannon")
        Dim TreeNode33 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Kallidan Linear Accelerator")
        Dim TreeNode34 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Vengeance Lance")
        Dim TreeNode35 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Hexa-Mount Turbo-Laser Destroyer")
        Dim TreeNode36 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Plasma Immolator")
        Dim TreeNode37 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Hexa-Mount Vulcan Megabolter")
        Dim TreeNode38 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Quad-Mount Apocalypse Missile Launcher")
        Dim TreeNode39 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Emperator", New System.Windows.Forms.TreeNode() {TreeNode31, TreeNode32, TreeNode33, TreeNode34, TreeNode35, TreeNode36, TreeNode37, TreeNode38})
        Dim TreeNode40 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Weaponry Configurations", New System.Windows.Forms.TreeNode() {TreeNode5, TreeNode16, TreeNode23, TreeNode30, TreeNode39})
        Dim TreeNode41 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Greyhound Chassis")
        Dim TreeNode42 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Mastiff Chassis")
        Dim TreeNode43 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Chulainn Chassis")
        Dim TreeNode44 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warhound", New System.Windows.Forms.TreeNode() {TreeNode41, TreeNode42, TreeNode43})
        Dim TreeNode45 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Gladiator Chassis")
        Dim TreeNode46 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Sentinel Chassis")
        Dim TreeNode47 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Interceptor Chassis")
        Dim TreeNode48 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Reaver", New System.Windows.Forms.TreeNode() {TreeNode45, TreeNode46, TreeNode47})
        Dim TreeNode49 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Barrage Chassis")
        Dim TreeNode50 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Astraea Chassis")
        Dim TreeNode51 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Corona Chassis")
        Dim TreeNode52 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warbringer", New System.Windows.Forms.TreeNode() {TreeNode49, TreeNode50, TreeNode51})
        Dim TreeNode53 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Solais Ira Chassis")
        Dim TreeNode54 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Panopticon Chassis")
        Dim TreeNode55 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Thronebreaker Chassis")
        Dim TreeNode56 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warlord", New System.Windows.Forms.TreeNode() {TreeNode53, TreeNode54, TreeNode55})
        Dim TreeNode57 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Paladin Chassis")
        Dim TreeNode58 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Skyshock Chassis")
        Dim TreeNode59 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Xenia Chassis")
        Dim TreeNode60 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Challenger Chassis")
        Dim TreeNode61 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Emperator", New System.Windows.Forms.TreeNode() {TreeNode57, TreeNode58, TreeNode59, TreeNode60})
        Dim TreeNode62 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Equipment Configurations", New System.Windows.Forms.TreeNode() {TreeNode44, TreeNode48, TreeNode52, TreeNode56, TreeNode61})
        Dim TreeNode63 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Titan Name:")
        Dim TreeNode64 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Titan One Type:")
        Dim TreeNode65 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Titan One Sub-Chassis")
        Dim TreeNode66 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Titan One", New System.Windows.Forms.TreeNode() {TreeNode63, TreeNode64, TreeNode65})
        Dim TreeNode67 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("")
        Dim TreeNode68 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("")
        Dim TreeNode69 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("")
        Dim TreeNode70 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("")
        Dim TreeNode71 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Weaponry", New System.Windows.Forms.TreeNode() {TreeNode67, TreeNode68, TreeNode69, TreeNode70})
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.titanOneCore = New System.Windows.Forms.TextBox()
        Me.titanOneRback = New System.Windows.Forms.TextBox()
        Me.titanOneLback = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.titanOneRarm = New System.Windows.Forms.TextBox()
        Me.titanOneLarm = New System.Windows.Forms.TextBox()
        Me.TitanOneType = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.titanOneName = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.TitanOneErrorBox = New System.Windows.Forms.TextBox()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ProgressBar3 = New System.Windows.Forms.ProgressBar()
        Me.ProgressBar4 = New System.Windows.Forms.ProgressBar()
        Me.ProgressBar5 = New System.Windows.Forms.ProgressBar()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.comComponentBox = New System.Windows.Forms.ComboBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TreeView2 = New System.Windows.Forms.TreeView()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(308, 281)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(61, 20)
        Me.Label13.TabIndex = 38
        Me.Label13.Text = "Label13"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(308, 247)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(61, 20)
        Me.Label14.TabIndex = 37
        Me.Label14.Text = "Label14"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(367, 278)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(125, 27)
        Me.TextBox13.TabIndex = 36
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(367, 244)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(125, 27)
        Me.TextBox14.TabIndex = 35
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(367, 210)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(125, 27)
        Me.TextBox15.TabIndex = 34
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(308, 213)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(61, 20)
        Me.Label15.TabIndex = 33
        Me.Label15.Text = "Label15"
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(367, 176)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(125, 27)
        Me.TextBox16.TabIndex = 32
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(367, 143)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(125, 27)
        Me.TextBox17.TabIndex = 31
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(367, 110)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(125, 27)
        Me.TextBox18.TabIndex = 30
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(308, 179)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(61, 20)
        Me.Label16.TabIndex = 29
        Me.Label16.Text = "Label16"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(308, 146)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(61, 20)
        Me.Label17.TabIndex = 28
        Me.Label17.Text = "Label17"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(308, 113)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(61, 20)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = "Label18"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(367, 311)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(125, 29)
        Me.Button3.TabIndex = 26
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 229)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 20)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Core"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 191)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 20)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "RBack"
        '
        'titanOneCore
        '
        Me.titanOneCore.Location = New System.Drawing.Point(88, 226)
        Me.titanOneCore.Name = "titanOneCore"
        Me.titanOneCore.Size = New System.Drawing.Size(125, 27)
        Me.titanOneCore.TabIndex = 23
        '
        'titanOneRback
        '
        Me.titanOneRback.Location = New System.Drawing.Point(88, 188)
        Me.titanOneRback.Name = "titanOneRback"
        Me.titanOneRback.Size = New System.Drawing.Size(125, 27)
        Me.titanOneRback.TabIndex = 22
        '
        'titanOneLback
        '
        Me.titanOneLback.Location = New System.Drawing.Point(88, 155)
        Me.titanOneLback.Name = "titanOneLback"
        Me.titanOneLback.Size = New System.Drawing.Size(125, 27)
        Me.titanOneLback.TabIndex = 21
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 158)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 20)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "LBack"
        '
        'titanOneRarm
        '
        Me.titanOneRarm.Location = New System.Drawing.Point(88, 121)
        Me.titanOneRarm.Name = "titanOneRarm"
        Me.titanOneRarm.Size = New System.Drawing.Size(125, 27)
        Me.titanOneRarm.TabIndex = 19
        '
        'titanOneLarm
        '
        Me.titanOneLarm.Location = New System.Drawing.Point(88, 88)
        Me.titanOneLarm.Name = "titanOneLarm"
        Me.titanOneLarm.Size = New System.Drawing.Size(125, 27)
        Me.titanOneLarm.TabIndex = 18
        '
        'TitanOneType
        '
        Me.TitanOneType.Location = New System.Drawing.Point(88, 55)
        Me.TitanOneType.Name = "TitanOneType"
        Me.TitanOneType.Size = New System.Drawing.Size(125, 27)
        Me.TitanOneType.TabIndex = 17
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 124)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 20)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "RArm"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 91)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 20)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "LArm"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 20)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Type"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(88, 511)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(125, 29)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Accept"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'titanOneName
        '
        Me.titanOneName.Location = New System.Drawing.Point(57, 22)
        Me.titanOneName.Name = "titanOneName"
        Me.titanOneName.Size = New System.Drawing.Size(184, 27)
        Me.titanOneName.TabIndex = 65
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(932, 299)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(185, 27)
        Me.TextBox1.TabIndex = 69
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(932, 332)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(185, 27)
        Me.TextBox2.TabIndex = 70
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(932, 366)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(185, 27)
        Me.TextBox3.TabIndex = 71
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(780, 195)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(141, 20)
        Me.Label31.TabIndex = 72
        Me.Label31.Text = "Power verus Infantry"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(780, 226)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(144, 20)
        Me.Label32.TabIndex = 73
        Me.Label32.Text = "Power verus Vehicles"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(780, 255)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(136, 20)
        Me.Label33.TabIndex = 74
        Me.Label33.Text = "Power versus Titans"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(765, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(391, 170)
        Me.TabControl1.TabIndex = 75
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TreeView1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(383, 137)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Weaponry and Equipment"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TreeView1
        '
        Me.TreeView1.Location = New System.Drawing.Point(-4, 0)
        Me.TreeView1.Name = "TreeView1"
        TreeNode1.Name = "Node32"
        TreeNode1.Text = "Plasma Blastgun"
        TreeNode2.Name = "Node33"
        TreeNode2.Text = "Inferno Cannon"
        TreeNode3.Name = "Node34"
        TreeNode3.Text = "Vulcan Megabolter"
        TreeNode4.Name = "Node35"
        TreeNode4.Text = "Turbo-Laser Destructor"
        TreeNode5.Name = "Node4"
        TreeNode5.Text = "Warhound"
        TreeNode6.Name = "Node29"
        TreeNode6.Text = "Volcano Cannon"
        TreeNode7.Name = "Node30"
        TreeNode7.Text = "Gatling Blaster"
        TreeNode8.Name = "Node53"
        TreeNode8.Text = "Triple-Barrel Turbo-Laser Destructor"
        TreeNode9.Name = "Node31"
        TreeNode9.Text = "Melta Cannon"
        TreeNode10.Name = "Node48"
        TreeNode10.Text = "Powerfist"
        TreeNode11.Name = "Node49"
        TreeNode11.Text = "Melta-Chainfist"
        TreeNode12.Name = "Node50"
        TreeNode12.Text = "Power Galatine"
        TreeNode13.Name = "Node51"
        TreeNode13.Text = "Carapace Vulcan Megabolter"
        TreeNode14.Name = "Node52"
        TreeNode14.Text = "Carapace Plasma Blastgun"
        TreeNode15.Name = "Node54"
        TreeNode15.Text = "Carapace Inferno Cannon"
        TreeNode16.Name = "Node5"
        TreeNode16.Text = "Reaver"
        TreeNode17.Name = "Node26"
        TreeNode17.Text = "Macro Gatling Blaster"
        TreeNode18.Name = "Node27"
        TreeNode18.Text = "Belicosa Volcano Cannon"
        TreeNode19.Name = "Node28"
        TreeNode19.Text = "Melta Cannon"
        TreeNode20.Name = "Node57"
        TreeNode20.Text = "Triple-Barrel Turbo-Laser Destructor"
        TreeNode21.Name = "Node55"
        TreeNode21.Text = "Nemesis (Carapace) Quake Cannon"
        TreeNode22.Name = "Node56"
        TreeNode22.Text = "Nemesis (Carapace) Kallidan Linear Accelerator"
        TreeNode23.Name = "Node6"
        TreeNode23.Text = "Warbringer"
        TreeNode24.Name = "Node22"
        TreeNode24.Text = "Macro Gatling Blaster"
        TreeNode25.Name = "Node23"
        TreeNode25.Text = "Belicosa Volcano Cannon"
        TreeNode26.Name = "Node24"
        TreeNode26.Text = "Mori Quake Cannon"
        TreeNode27.Name = "Node25"
        TreeNode27.Text = "Plasma Immolator"
        TreeNode28.Name = "Node58"
        TreeNode28.Text = "Carapace Apocalypse Missle Launcher"
        TreeNode29.Name = "Node59"
        TreeNode29.Text = "Carapace Triple-Barrel Turbo-Laser Destructor"
        TreeNode30.Name = "Node7"
        TreeNode30.Text = "Warlord"
        TreeNode31.Name = "Node18"
        TreeNode31.Text = "Plasma Annihilator"
        TreeNode32.Name = "Node19"
        TreeNode32.Text = "Hellstorm Cannon"
        TreeNode33.Name = "Node20"
        TreeNode33.Text = "Kallidan Linear Accelerator"
        TreeNode34.Name = "Node21"
        TreeNode34.Text = "Vengeance Lance"
        TreeNode35.Name = "Node60"
        TreeNode35.Text = "Carapace Hexa-Mount Turbo-Laser Destroyer"
        TreeNode36.Name = "Node61"
        TreeNode36.Text = "Carapace Plasma Immolator"
        TreeNode37.Name = "Node62"
        TreeNode37.Text = "Carapace Hexa-Mount Vulcan Megabolter"
        TreeNode38.Name = "Node63"
        TreeNode38.Text = "Carapace Quad-Mount Apocalypse Missile Launcher"
        TreeNode39.Name = "Node17"
        TreeNode39.Text = "Emperator"
        TreeNode40.Name = "Node0"
        TreeNode40.Text = "Weaponry Configurations"
        TreeNode41.Name = "Node14"
        TreeNode41.Text = "Greyhound Chassis"
        TreeNode42.Name = "Node15"
        TreeNode42.Text = "Mastiff Chassis"
        TreeNode43.Name = "Node16"
        TreeNode43.Text = "Chulainn Chassis"
        TreeNode44.Name = "Node9"
        TreeNode44.Text = "Warhound"
        TreeNode45.Name = "Node36"
        TreeNode45.Text = "Gladiator Chassis"
        TreeNode46.Name = "Node37"
        TreeNode46.Text = "Sentinel Chassis"
        TreeNode47.Name = "Node38"
        TreeNode47.Text = "Interceptor Chassis"
        TreeNode48.Name = "Node10"
        TreeNode48.Text = "Reaver"
        TreeNode49.Name = "Node39"
        TreeNode49.Text = "Barrage Chassis"
        TreeNode50.Name = "Node40"
        TreeNode50.Text = "Astraea Chassis"
        TreeNode51.Name = "Node41"
        TreeNode51.Text = "Corona Chassis"
        TreeNode52.Name = "Node11"
        TreeNode52.Text = "Warbringer"
        TreeNode53.Name = "Node42"
        TreeNode53.Text = "Solais Ira Chassis"
        TreeNode54.Name = "Node43"
        TreeNode54.Text = "Panopticon Chassis"
        TreeNode55.Name = "Node44"
        TreeNode55.Text = "Thronebreaker Chassis"
        TreeNode56.Name = "Node12"
        TreeNode56.Text = "Warlord"
        TreeNode57.Name = "Node45"
        TreeNode57.Text = "Paladin Chassis"
        TreeNode58.Name = "Node46"
        TreeNode58.Text = "Skyshock Chassis"
        TreeNode59.Name = "Node47"
        TreeNode59.Text = "Xenia Chassis"
        TreeNode60.Name = "Node2"
        TreeNode60.Text = "Challenger Chassis"
        TreeNode61.Name = "Node13"
        TreeNode61.Text = "Emperator"
        TreeNode62.Name = "Node1"
        TreeNode62.Text = "Equipment Configurations"
        Me.TreeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode40, TreeNode62})
        Me.TreeView1.Size = New System.Drawing.Size(391, 147)
        Me.TreeView1.TabIndex = 0
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(88, 325)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(125, 29)
        Me.ProgressBar1.TabIndex = 76
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(121, 302)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(51, 20)
        Me.Label34.TabIndex = 77
        Me.Label34.Text = "Speed"
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(88, 392)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(125, 29)
        Me.ProgressBar2.TabIndex = 78
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(113, 369)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(59, 20)
        Me.Label35.TabIndex = 79
        Me.Label35.Text = "Armour"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(121, 445)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(61, 20)
        Me.Label36.TabIndex = 81
        Me.Label36.Text = "Label36"
        '
        'TitanOneErrorBox
        '
        Me.TitanOneErrorBox.Location = New System.Drawing.Point(88, 468)
        Me.TitanOneErrorBox.Name = "TitanOneErrorBox"
        Me.TitanOneErrorBox.Size = New System.Drawing.Size(125, 27)
        Me.TitanOneErrorBox.TabIndex = 100
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Location = New System.Drawing.Point(257, 12)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(422, 203)
        Me.TabControl2.TabIndex = 101
        '
        'TabPage6
        '
        Me.TabPage6.AutoScroll = True
        Me.TabPage6.AutoScrollMargin = New System.Drawing.Size(0, 100)
        Me.TabPage6.Controls.Add(Me.TextBox10)
        Me.TabPage6.Controls.Add(Me.TreeView2)
        Me.TabPage6.Location = New System.Drawing.Point(4, 29)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(414, 170)
        Me.TabPage6.TabIndex = 0
        Me.TabPage6.Text = "Your Titan Formations"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Vanguard", "Rear-Guard", "Anti-Infantry", "Anti-Vehicle", "Anti-Titan", "Anti-Air", "Anti-Building", "Annihilator"})
        Me.ComboBox1.Location = New System.Drawing.Point(88, 273)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(125, 28)
        Me.ComboBox1.TabIndex = 102
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(5, 273)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 20)
        Me.Label7.TabIndex = 103
        Me.Label7.Text = "Formation"
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage2)
        Me.TabControl3.Location = New System.Drawing.Point(257, 217)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(422, 203)
        Me.TabControl3.TabIndex = 104
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(414, 170)
        Me.TabPage2.TabIndex = 0
        Me.TabPage2.Text = "Enemy Formation"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(975, 468)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(94, 29)
        Me.Button2.TabIndex = 105
        Me.Button2.Text = "Compare"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(716, 302)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(205, 20)
        Me.Label8.TabIndex = 106
        Me.Label8.Text = "Enemy Guardsmen Equivelent"
        '
        'ProgressBar3
        '
        Me.ProgressBar3.Location = New System.Drawing.Point(927, 188)
        Me.ProgressBar3.Name = "ProgressBar3"
        Me.ProgressBar3.Size = New System.Drawing.Size(125, 29)
        Me.ProgressBar3.TabIndex = 107
        '
        'ProgressBar4
        '
        Me.ProgressBar4.Location = New System.Drawing.Point(927, 217)
        Me.ProgressBar4.Name = "ProgressBar4"
        Me.ProgressBar4.Size = New System.Drawing.Size(125, 29)
        Me.ProgressBar4.TabIndex = 108
        '
        'ProgressBar5
        '
        Me.ProgressBar5.Location = New System.Drawing.Point(927, 246)
        Me.ProgressBar5.Name = "ProgressBar5"
        Me.ProgressBar5.Size = New System.Drawing.Size(125, 29)
        Me.ProgressBar5.TabIndex = 109
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(932, 399)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(185, 27)
        Me.TextBox4.TabIndex = 110
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(932, 432)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(185, 27)
        Me.TextBox5.TabIndex = 111
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(701, 335)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(220, 20)
        Me.Label9.TabIndex = 112
        Me.Label9.Text = "Enemy Space Marine Equivelent"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(744, 369)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(177, 20)
        Me.Label10.TabIndex = 113
        Me.Label10.Text = "Enemy Vehicle Equivelent"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(727, 402)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(194, 20)
        Me.Label11.TabIndex = 114
        Me.Label11.Text = "Enemy Ordinatus Equivelent"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(758, 435)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(163, 20)
        Me.Label12.TabIndex = 115
        Me.Label12.Text = "Enemy Titan Equivelent"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(88, 597)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(1029, 120)
        Me.RichTextBox1.TabIndex = 116
        Me.RichTextBox1.Text = ""
        '
        'comComponentBox
        '
        Me.comComponentBox.FormattingEnabled = True
        Me.comComponentBox.Items.AddRange(New Object() {"Apocalypse Missile Launcher", "Belicosa Volcano Cannon", "Doomstrike Missile Launcher", "Gatling Blaster", "Hellstorm Cannon", "Inferno Cannon", "Kalidan Linear Accelerator", "Macro Gatling Blaster", "Melta Cannon", "Melta-Chainfist", "Morai Quake Cannon", "Nemesis Kalidan Linear Accelerator", "Nemesis Quake Cannon", "Plasma Annihilator", "Plasma Blastgun", "Power Galatine", "Plasma Immolator", "Turbo-Laser Destructor", "Vengeance Lance", "Volcano Cannon", "Vulcan Megabolter"})
        Me.comComponentBox.Location = New System.Drawing.Point(384, 528)
        Me.comComponentBox.Name = "comComponentBox"
        Me.comComponentBox.Size = New System.Drawing.Size(151, 28)
        Me.comComponentBox.TabIndex = 117
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(384, 562)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(151, 29)
        Me.Button4.TabIndex = 118
        Me.Button4.Text = "Button4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(230, 531)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(148, 20)
        Me.Label19.TabIndex = 119
        Me.Label19.Text = "Selected Component"
        '
        'TreeView2
        '
        Me.TreeView2.Location = New System.Drawing.Point(3, 0)
        Me.TreeView2.Name = "TreeView2"
        TreeNode63.Name = "Node1"
        TreeNode63.Text = "Titan Name:"
        TreeNode64.Name = "Node7"
        TreeNode64.Text = "Titan One Type:"
        TreeNode65.Name = "Node8"
        TreeNode65.Text = "Titan One Sub-Chassis"
        TreeNode66.Name = "Node0"
        TreeNode66.Text = "Titan One"
        TreeNode67.Name = "Node3"
        TreeNode67.Text = ""
        TreeNode68.Name = "Node4"
        TreeNode68.Text = ""
        TreeNode69.Name = "Node5"
        TreeNode69.Text = ""
        TreeNode70.Name = "Node6"
        TreeNode70.Text = ""
        TreeNode71.Name = "Node2"
        TreeNode71.Text = "Weaponry"
        Me.TreeView2.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode66, TreeNode71})
        Me.TreeView2.Size = New System.Drawing.Size(391, 202)
        Me.TreeView2.TabIndex = 12
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(3, 29)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(125, 27)
        Me.TextBox10.TabIndex = 13
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1159, 752)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.comComponentBox)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.ProgressBar5)
        Me.Controls.Add(Me.ProgressBar4)
        Me.Controls.Add(Me.ProgressBar3)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TabControl3)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.TitanOneErrorBox)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.ProgressBar2)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.titanOneName)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.titanOneCore)
        Me.Controls.Add(Me.titanOneRback)
        Me.Controls.Add(Me.titanOneLback)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.titanOneRarm)
        Me.Controls.Add(Me.titanOneLarm)
        Me.Controls.Add(Me.TitanOneType)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Titan Maniple Power Rating"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabControl3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents titanOneCore As TextBox
    Friend WithEvents titanOneRback As TextBox
    Friend WithEvents titanOneLback As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents titanOneRarm As TextBox
    Friend WithEvents titanOneLarm As TextBox
    Friend WithEvents TitanOneType As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents titanOneName As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TreeView1 As TreeView
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents Label34 As Label
    Friend WithEvents ProgressBar2 As ProgressBar
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents TitanOneErrorBox As TextBox
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TabControl3 As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Button2 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents ProgressBar3 As ProgressBar
    Friend WithEvents ProgressBar4 As ProgressBar
    Friend WithEvents ProgressBar5 As ProgressBar
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents comComponentBox As ComboBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TreeView2 As TreeView
End Class
