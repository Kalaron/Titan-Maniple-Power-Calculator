﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Dim titanOneNameQ As String
        Dim titanOneTypeQ As String
        Dim titanOneLarmQ As String
        Dim TitanOneLarmValue As Double
        Dim titanOneRarmQ As String
        Dim TitanOneRarmValue As Double
        Dim titanOneLbackQ As String
        Dim TitanOneLbackValue As Double
        Dim titanOneRbackQ As String
        Dim TitanOneRbackValue As Double
        Dim titanOneCoreQ As String
        Dim TitanOneCoreValue As Double
        titanOneNameQ = titanName.Text
        titanOneTypeQ = combtitanType.Text
        titanOneLarmQ = combTitanLarm.Text
        titanOneRarmQ = combTitanRArm.Text
        titanOneLbackQ = comboTitanLBack.Text
        titanOneRbackQ = combTitanRBack.Text
        titanOneCoreQ = combTitanSubtype.Text
        Dim titanOneMaximumValue As Double
        Dim TitanOneCurrentValue As Double
        Dim typeWarhound As String
        typeWarhound = "Warhound"
        Dim WarhoundValue As Double
        Dim typeReaver As String
        typeReaver = "Reaver"
        Dim ReaverValue As Double
        Dim typeWarlord As String
        typeWarlord = "Warlord"
        Dim WarlordValue As Double
        Dim typeEmperator As String
        typeEmperator = "Emperator"
        Dim EmparatorValue As Double
        Dim typeWarbringer As String
        typeWarbringer = "Warbringer"
        Dim WarbringerValue As Double
        Dim weaponLTInfernoCannon As String
        weaponLTInfernoCannon = "Inferno Cannon"
        Dim LtInfernoCannonValue As Double = 50
        Dim weaponLTPlasmaBlastgun As String
        weaponLTPlasmaBlastgun = "Plasma Blastgun"
        Dim LtPlasmaBlastgunValue As Double = 50
        Dim weaponLTTurboDestructor As String
        weaponLTTurboDestructor = "Turbo Destructor"
        Dim LTTurboDestructorValue As Double = 50
        Dim weaponLtVulcanMegaBlaster As String
        weaponLtVulcanMegaBlaster = "Vulcan Megablaster"
        Dim LtVulcanMegaBlasterValue As Double = 50
        Dim weaponGatlingBlaster As String
        weaponGatlingBlaster = "Gatling Blaster"
        Dim GatlingBlaster As Double = 200
        Dim weaponMeltaCannon As String
        weaponMeltaCannon = "Melta Cannon"
        Dim MeltaCannonValue As Double = 200
        Dim weaponQuakeCannon As String
        weaponQuakeCannon = "Quake Cannon"
        Dim QuakeCannonValue As Double = 200
        Dim weaponVolcanoCannon As String
        weaponVolcanoCannon = "Volcano Cannon"
        Dim VolcanoCannonValue As Double = 200
        Dim weaponPlasmaAnnihilator As String
        weaponPlasmaAnnihilator = "Plasma Annihilator" And "Sunfury Plasma Annihilator"
        Dim PlasmaAnnihilatorValue As Double = 2400
        Dim weaponHellstormCannon As String
        weaponHellstormCannon = "Hellstorm Cannon"
        Dim HellstormCannonValue As Double = 2400
        Dim weaponApocalypseMissileLauncher As String
        weaponApocalypseMissileLauncher = "Apocalypse Missile Launcher"
        Dim ApocalypseMissileValue As Double = 200
        Dim weaponVortexMissileLauncher As String
        weaponVortexMissileLauncher = "Vortex Missile Launcher"
        Dim VortexMissileValue As Double = 200
        Dim EquipmentCarpaceLandingPad As String
        EquipmentCarpaceLandingPad = "Landing Pad" Or "Landing Pod"
        Dim CarapaceLandinPadValue As Double = 200
        Dim weaponCarpaceMountedMultiLasers As String
        weaponCarpaceMountedMultiLasers = "Multi-Lasers"
        Dim CarapaceMountedMultiLasersValue As Double = 200
        Dim weaponDeathStrikeCannon As String
        weaponDeathStrikeCannon = "Deathstrike Cannon"
        Dim DeathstrikeCannonValue As Double = 200
        Dim weaponDevastatorMissile As String
        weaponDevastatorMissile = "Devastator Missile"
        Dim weaponDevastatorMissileValue As Double
        Dim qualitySlowFiring As Double
        Dim qualityFastFiring As Double
        Dim qualityLargeBlast As Double
        Dim qualitySmallBlast As Double
        Dim qualityPlasma As Double
        Dim qualityConversion As Double
        Dim qualityNumberofPersonnel As Double
        titanOneTypeQ = CompletedOneName.Text
        If combtitanType.Text = "Warhound" Then

        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label32_Click(sender As Object, e As EventArgs) Handles Label32.Click

    End Sub

    Private Sub TreeView2_AfterSelect(sender As Object, e As TreeViewEventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        If comComponentBox.Text = "Plasma Blastgun" Then
            RichTextBox1.Text = "A short-range Plasma Weapon produced by the Kalidan Mechanicus for the Warhound Scout Titan, these weapons are capable of super-charging their output by drawing power from both the Titan Reactor and intergrated Plasma-Tap Sub-Reactor.
        Though this dangerously stresses the thermal casing on the Core, it does allow for the weapon to fire much more devastatingly charged projectiles. Ammunition is drawn from internal Deuterium Reserves inside the Titan Core, allowing the Weapon to be fired hundreds or thousands of times on a full Titan, though the most devestating models can actually deplete entire fuel cells when the safeties are removed."
        ElseIf comComponentBox.Text = "Inferno Cannon" Then
            RichTextBox1.Text = "Firing a nanothermite compound capable of burning at 3632°F regardless of the presence of an atmosphere, the Inferno Cannon is a potent Anti-Infantry weapon and capable of turning lesser vehicles into molten slag. A typical strategy for Warhound Units deployed with Inferno Cannons is to surround a building and immerse a particular side in fire while the Warhound on the otherside lays in wait. When the Renegade Guardsmen, Space Marines, or Tyranid inside is unable to stand the heat any longer and flees, the hidden member of the Titan Pair will spring, immersing them in the fluid or stomping on them with all their mass."
        ElseIf comComponentBox.Text = "Vulcan Megabolter" Then
            RichTextBox1.Text = "Essentially consisting of two pairs of five linked heavy bolters, the Vulcan Megabolter unleashes a hellish hail of munitons across a selected arc of the battlefield. Each shell, itself on the order of 45mm wide, carries a High Explosive AntI-Tank warhead primed to explode upon a confirmation from three redundent sensors. An initial laser designation auspex primes the Shell, while secondary Optical and RF sensors ensure the target is the correct one before letting off an optimized burst of explosively formed penetrators. Due to the need to balance those Titans capable of mounting the weapon, the actual shell casings are routed back inside of the Titan's cargo holds. This, combined with an automatic gyroscope designed to reduce the recoil of the weapon, helps to keep even the ligthest Imperial Titan grounded during regular firing. It isn't unknown, even, for a Greyhound equipped with Vulcan Megabolters to set their target aquisition to automatic while the crew focused on staying either airborne or mobile."
        ElseIf comComponentBox.Text = "Power Galatine" Then
            RichTextBox1.Text = "A dreadfully destructive weapon designed during the Dark Age of Technology, directly after the first Hyper-Advanced Primordial Forge invaded another stricken by the rampent spreading corruption of Men of Iron. Faced with a sky that burned with each invading Titan's graviometric parachute, and an atmosphere that smogged full of clogging and burning contaimenents from the massive Fleet-Based Thermoionic Broadsides, the Federation General Kirkland demanded a reliable weapon to arm the 86th Fusiliers from the Printing Forges of Orle Taig. Their answer was the almost Phase-like Force Galatine. This weapon is so ancient as to be unknown outside of a select number of Forge worlds that consider themselves open to the old secrets of the Forge such as Deimo, Titan, Metallica and Kalidan, this blade is capable of instantly vaporizing whole Titan Weapon Connections with a single cleave, and of piercing even the thickest Void Shield armour due to the the strange mechanism of it's Power Field. Instead of constantly keeping active during combat, the blade elements instead dynamically channel power a split second before striking the field of another Power Weapon. This sudden field creation is capable of either damaging or outright shattering projector Components in the opposing blade due to the sudden stress of countering it's manifestation. Capped with a Tungsten Diboride end-reinforcement for the massive emitters for the blade, the Galtine looks almost blunted at the end as though it were actually an Executioner's sword."
        ElseIf comComponentBox.Text = "Nemesis Quake Cannon" Then
            RichTextBox1.Text = "The Nemesis Quake Cannon is a weapon designed to shatter the armour of Enemy Titan's through the use of massive, heavy shells. The Nemesis model of the Quake Cannon is notable both for it's superior ammunition capacity and it's more powerfully charged shells. A Revolving Cylinder feeds the Cannon, with a an automatic shell ramming system feeding into the lowest ammunition-slot to provide a near-constant stream of firepower. In extreme cases, this reloading system can be delayed so as to provide a burst of firepower, including the potential for a six-shot salvo. "
        ElseIf comComponentBox.Text = "Nemesis Kalidan Linear Accelerator" Then
            RichTextBox1.Text = ""
        ElseIf comComponentBox.Text = "Mori Quake Cannon" Then
            RichTextBox1.Text = ""
        ElseIf comComponentBox.Text = "Plasma Annihilator" Then
            RichTextBox1.Text = "Designed to shatter and flash-fuse the Earth from miles away, the Plasma Annihilator is a weapon fitted to Emperator Titans to provide them with the ability to purge entire kilometers of battleground per firing. When the discharge of this weapon strikes an object, almost regardless of it's composition, the target is instantly blanketed in a globule of plasma dozens of meters wide and only slightly cooler than the center of a fission blast. Almost invariably, this results in the vaporization of the Target's armour if not the wholesale eradication of the Target. Even Titans often suffer critical damage against this weapon as the heat of the weapon can damage their subsystems and weaken their joints if a lapse in the barrage isn't presented immediately. Some theorize that these weapons first begas as a radical upscaling of the Dark Age of Technology's plasmafied mining industry, where the exceedingly intense blasts of plasma could be siphoned from the impact area and subjected to later processing to remove valuable elements from the mixture."
        ElseIf comComponentBox.Text = "Vegeance Lance" Then
            RichTextBox1.Text = "An ancient weapon stemming from Humanity's early history of stellar Exploration, the Vengeance Lance was a weapon fitted to some of the lightest Frigates of Humankind. Designed for use outside of the Atmosphere, it's capable of "
        ElseIf comComponentBox.Text = "Gatling Blaster" Then
            RichTextBox1.Text = "One of the oldest components available to the Reavers, the Gatling Blaster is actually a modification of the STC for the Macro-Gatling Blaster, which retroactively obtained the 'Macro' designation, designed during the opening days of the Great Crusader by the Martian "
        ElseIf comComponentBox.Text = "Macro Gatling Blaster" Then
            RichTextBox1.Text = ""
        ElseIf comComponentBox.Text = "Saturnyne Lascutter" Then
            RichTextBox1.Text = ""
        ElseIf comComponentBox.Text = "Turbo-Laser Destructor" Then
            RichTextBox1.Text = ""
        ElseIf comComponentBox.Text = "Melta Chainfist" Then
            RichTextBox1.Text = ""
        ElseIf comComponentBox.Text = "Powerfist" Then
            RichTextBox1.Text = ""
        ElseIf comComponentBox.Text = "Kalidan Linear Accelerator" Then
            RichTextBox1.Text = ""
        ElseIf comComponentBox.Text = "Soliton Wave Blade" Then
            RichTextBox1.Text = ""
        ElseIf comComponentBox.Text = "Scalar Wave Array" Then
            RichTextBox1.Text = "A set of weaponry designed for mountin on an Emperator Titan at the lightest, the Scalar Wave Array consists of three highly "
        End If
    End Sub

    Private Sub TreeView2_AfterSelect_1(sender As Object, e As TreeViewEventArgs)

    End Sub

    Private Sub TabControl2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl2.SelectedIndexChanged

    End Sub

    Private Sub Label22_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CompletedOneRightArm_TextChanged(sender As Object, e As EventArgs) Handles CompletedOneRightArm.TextChanged

    End Sub
End Class
