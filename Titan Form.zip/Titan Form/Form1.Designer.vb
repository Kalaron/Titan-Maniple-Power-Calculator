﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim TreeNode63 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Plasma Blastgun")
        Dim TreeNode64 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Inferno Cannon")
        Dim TreeNode65 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Vulcan Megabolter")
        Dim TreeNode66 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Turbo-Laser Destructor")
        Dim TreeNode67 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warhound", New System.Windows.Forms.TreeNode() {TreeNode63, TreeNode64, TreeNode65, TreeNode66})
        Dim TreeNode68 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Volcano Cannon")
        Dim TreeNode69 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Gatling Blaster")
        Dim TreeNode70 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Triple-Barrel Turbo-Laser Destructor")
        Dim TreeNode71 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Melta Cannon")
        Dim TreeNode72 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Powerfist")
        Dim TreeNode73 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Melta-Chainfist")
        Dim TreeNode74 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Power Galatine")
        Dim TreeNode75 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Vulcan Megabolter")
        Dim TreeNode76 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Plasma Blastgun")
        Dim TreeNode77 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Inferno Cannon")
        Dim TreeNode78 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Reaver", New System.Windows.Forms.TreeNode() {TreeNode68, TreeNode69, TreeNode70, TreeNode71, TreeNode72, TreeNode73, TreeNode74, TreeNode75, TreeNode76, TreeNode77})
        Dim TreeNode79 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Macro Gatling Blaster")
        Dim TreeNode80 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Belicosa Volcano Cannon")
        Dim TreeNode81 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Melta Cannon")
        Dim TreeNode82 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Triple-Barrel Turbo-Laser Destructor")
        Dim TreeNode83 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nemesis (Carapace) Quake Cannon")
        Dim TreeNode84 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nemesis (Carapace) Kallidan Linear Accelerator")
        Dim TreeNode85 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warbringer", New System.Windows.Forms.TreeNode() {TreeNode79, TreeNode80, TreeNode81, TreeNode82, TreeNode83, TreeNode84})
        Dim TreeNode86 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Macro Gatling Blaster")
        Dim TreeNode87 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Belicosa Volcano Cannon")
        Dim TreeNode88 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Mori Quake Cannon")
        Dim TreeNode89 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Plasma Immolator")
        Dim TreeNode90 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Apocalypse Missle Launcher")
        Dim TreeNode91 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Triple-Barrel Turbo-Laser Destructor")
        Dim TreeNode92 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warlord", New System.Windows.Forms.TreeNode() {TreeNode86, TreeNode87, TreeNode88, TreeNode89, TreeNode90, TreeNode91})
        Dim TreeNode93 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Plasma Annihilator")
        Dim TreeNode94 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Hellstorm Cannon")
        Dim TreeNode95 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Kallidan Linear Accelerator")
        Dim TreeNode96 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Vengeance Lance")
        Dim TreeNode97 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Hexa-Mount Turbo-Laser Destroyer")
        Dim TreeNode98 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Plasma Immolator")
        Dim TreeNode99 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Hexa-Mount Vulcan Megabolter")
        Dim TreeNode100 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Carapace Quad-Mount Apocalypse Missile Launcher")
        Dim TreeNode101 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Emperator", New System.Windows.Forms.TreeNode() {TreeNode93, TreeNode94, TreeNode95, TreeNode96, TreeNode97, TreeNode98, TreeNode99, TreeNode100})
        Dim TreeNode102 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Weaponry Configurations", New System.Windows.Forms.TreeNode() {TreeNode67, TreeNode78, TreeNode85, TreeNode92, TreeNode101})
        Dim TreeNode103 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Greyhound Chassis")
        Dim TreeNode104 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Mastiff Chassis")
        Dim TreeNode105 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Chulainn Chassis")
        Dim TreeNode106 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warhound", New System.Windows.Forms.TreeNode() {TreeNode103, TreeNode104, TreeNode105})
        Dim TreeNode107 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Gladiator Chassis")
        Dim TreeNode108 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Sentinel Chassis")
        Dim TreeNode109 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Interceptor Chassis")
        Dim TreeNode110 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Reaver", New System.Windows.Forms.TreeNode() {TreeNode107, TreeNode108, TreeNode109})
        Dim TreeNode111 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Barrage Chassis")
        Dim TreeNode112 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Astraea Chassis")
        Dim TreeNode113 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Corona Chassis")
        Dim TreeNode114 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warbringer", New System.Windows.Forms.TreeNode() {TreeNode111, TreeNode112, TreeNode113})
        Dim TreeNode115 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Solais Ira Chassis")
        Dim TreeNode116 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Panopticon Chassis")
        Dim TreeNode117 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Thronebreaker Chassis")
        Dim TreeNode118 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warlord", New System.Windows.Forms.TreeNode() {TreeNode115, TreeNode116, TreeNode117})
        Dim TreeNode119 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Paladin Chassis")
        Dim TreeNode120 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Skyshock Chassis")
        Dim TreeNode121 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Xenia Chassis")
        Dim TreeNode122 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Challenger Chassis")
        Dim TreeNode123 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Emperator", New System.Windows.Forms.TreeNode() {TreeNode119, TreeNode120, TreeNode121, TreeNode122})
        Dim TreeNode124 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Equipment Configurations", New System.Windows.Forms.TreeNode() {TreeNode106, TreeNode110, TreeNode114, TreeNode118, TreeNode123})
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.titanName = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.TitanOneErrorBox = New System.Windows.Forms.TextBox()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.completedOneType = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.CompletedOneSupportTwo = New System.Windows.Forms.TextBox()
        Me.CompleteOneSupportOne = New System.Windows.Forms.TextBox()
        Me.CompletedOneRMount = New System.Windows.Forms.TextBox()
        Me.CompletedOneLMount = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.CompletedOneRightArm = New System.Windows.Forms.TextBox()
        Me.CompletedOneLeftArm = New System.Windows.Forms.TextBox()
        Me.CompletedOneSubtype = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.CompletedOneName = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.CompletedOneCMount = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ProgressBar3 = New System.Windows.Forms.ProgressBar()
        Me.ProgressBar4 = New System.Windows.Forms.ProgressBar()
        Me.ProgressBar5 = New System.Windows.Forms.ProgressBar()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.comComponentBox = New System.Windows.Forms.ComboBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.combtitanType = New System.Windows.Forms.ComboBox()
        Me.combTitanLarm = New System.Windows.Forms.ComboBox()
        Me.combTitanRArm = New System.Windows.Forms.ComboBox()
        Me.combTitanRBack = New System.Windows.Forms.ComboBox()
        Me.comboTitanLBack = New System.Windows.Forms.ComboBox()
        Me.combTitanCBack = New System.Windows.Forms.ComboBox()
        Me.combTitanSubtype = New System.Windows.Forms.ComboBox()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(308, 281)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(61, 20)
        Me.Label13.TabIndex = 38
        Me.Label13.Text = "Label13"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(308, 247)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(61, 20)
        Me.Label14.TabIndex = 37
        Me.Label14.Text = "Label14"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(367, 278)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(125, 27)
        Me.TextBox13.TabIndex = 36
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(367, 244)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(125, 27)
        Me.TextBox14.TabIndex = 35
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(367, 210)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(125, 27)
        Me.TextBox15.TabIndex = 34
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(308, 213)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(61, 20)
        Me.Label15.TabIndex = 33
        Me.Label15.Text = "Label15"
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(367, 176)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(125, 27)
        Me.TextBox16.TabIndex = 32
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(367, 143)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(125, 27)
        Me.TextBox17.TabIndex = 31
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(367, 110)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(125, 27)
        Me.TextBox18.TabIndex = 30
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(308, 179)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(61, 20)
        Me.Label16.TabIndex = 29
        Me.Label16.Text = "Label16"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(308, 146)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(61, 20)
        Me.Label17.TabIndex = 28
        Me.Label17.Text = "Label17"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(308, 113)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(61, 20)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = "Label18"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(367, 311)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(125, 29)
        Me.Button3.TabIndex = 26
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(5, 264)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 20)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Titan Subtype"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 226)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 20)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "RBack"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 195)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 20)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "LBack"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 124)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 20)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "RArm"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 91)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 20)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "LArm"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 20)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Type"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(106, 512)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(125, 29)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Accept"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'titanName
        '
        Me.titanName.Location = New System.Drawing.Point(67, 12)
        Me.titanName.Name = "titanName"
        Me.titanName.Size = New System.Drawing.Size(184, 27)
        Me.titanName.TabIndex = 65
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(932, 299)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(185, 27)
        Me.TextBox1.TabIndex = 69
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(932, 332)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(185, 27)
        Me.TextBox2.TabIndex = 70
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(932, 366)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(185, 27)
        Me.TextBox3.TabIndex = 71
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(780, 195)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(141, 20)
        Me.Label31.TabIndex = 72
        Me.Label31.Text = "Power verus Infantry"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(780, 226)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(144, 20)
        Me.Label32.TabIndex = 73
        Me.Label32.Text = "Power verus Vehicles"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(780, 255)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(136, 20)
        Me.Label33.TabIndex = 74
        Me.Label33.Text = "Power versus Titans"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(765, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(391, 170)
        Me.TabControl1.TabIndex = 75
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TreeView1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(383, 137)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Weaponry and Equipment"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TreeView1
        '
        Me.TreeView1.Location = New System.Drawing.Point(-4, 0)
        Me.TreeView1.Name = "TreeView1"
        TreeNode63.Name = "Node32"
        TreeNode63.Text = "Plasma Blastgun"
        TreeNode64.Name = "Node33"
        TreeNode64.Text = "Inferno Cannon"
        TreeNode65.Name = "Node34"
        TreeNode65.Text = "Vulcan Megabolter"
        TreeNode66.Name = "Node35"
        TreeNode66.Text = "Turbo-Laser Destructor"
        TreeNode67.Name = "Node4"
        TreeNode67.Text = "Warhound"
        TreeNode68.Name = "Node29"
        TreeNode68.Text = "Volcano Cannon"
        TreeNode69.Name = "Node30"
        TreeNode69.Text = "Gatling Blaster"
        TreeNode70.Name = "Node53"
        TreeNode70.Text = "Triple-Barrel Turbo-Laser Destructor"
        TreeNode71.Name = "Node31"
        TreeNode71.Text = "Melta Cannon"
        TreeNode72.Name = "Node48"
        TreeNode72.Text = "Powerfist"
        TreeNode73.Name = "Node49"
        TreeNode73.Text = "Melta-Chainfist"
        TreeNode74.Name = "Node50"
        TreeNode74.Text = "Power Galatine"
        TreeNode75.Name = "Node51"
        TreeNode75.Text = "Carapace Vulcan Megabolter"
        TreeNode76.Name = "Node52"
        TreeNode76.Text = "Carapace Plasma Blastgun"
        TreeNode77.Name = "Node54"
        TreeNode77.Text = "Carapace Inferno Cannon"
        TreeNode78.Name = "Node5"
        TreeNode78.Text = "Reaver"
        TreeNode79.Name = "Node26"
        TreeNode79.Text = "Macro Gatling Blaster"
        TreeNode80.Name = "Node27"
        TreeNode80.Text = "Belicosa Volcano Cannon"
        TreeNode81.Name = "Node28"
        TreeNode81.Text = "Melta Cannon"
        TreeNode82.Name = "Node57"
        TreeNode82.Text = "Triple-Barrel Turbo-Laser Destructor"
        TreeNode83.Name = "Node55"
        TreeNode83.Text = "Nemesis (Carapace) Quake Cannon"
        TreeNode84.Name = "Node56"
        TreeNode84.Text = "Nemesis (Carapace) Kallidan Linear Accelerator"
        TreeNode85.Name = "Node6"
        TreeNode85.Text = "Warbringer"
        TreeNode86.Name = "Node22"
        TreeNode86.Text = "Macro Gatling Blaster"
        TreeNode87.Name = "Node23"
        TreeNode87.Text = "Belicosa Volcano Cannon"
        TreeNode88.Name = "Node24"
        TreeNode88.Text = "Mori Quake Cannon"
        TreeNode89.Name = "Node25"
        TreeNode89.Text = "Plasma Immolator"
        TreeNode90.Name = "Node58"
        TreeNode90.Text = "Carapace Apocalypse Missle Launcher"
        TreeNode91.Name = "Node59"
        TreeNode91.Text = "Carapace Triple-Barrel Turbo-Laser Destructor"
        TreeNode92.Name = "Node7"
        TreeNode92.Text = "Warlord"
        TreeNode93.Name = "Node18"
        TreeNode93.Text = "Plasma Annihilator"
        TreeNode94.Name = "Node19"
        TreeNode94.Text = "Hellstorm Cannon"
        TreeNode95.Name = "Node20"
        TreeNode95.Text = "Kallidan Linear Accelerator"
        TreeNode96.Name = "Node21"
        TreeNode96.Text = "Vengeance Lance"
        TreeNode97.Name = "Node60"
        TreeNode97.Text = "Carapace Hexa-Mount Turbo-Laser Destroyer"
        TreeNode98.Name = "Node61"
        TreeNode98.Text = "Carapace Plasma Immolator"
        TreeNode99.Name = "Node62"
        TreeNode99.Text = "Carapace Hexa-Mount Vulcan Megabolter"
        TreeNode100.Name = "Node63"
        TreeNode100.Text = "Carapace Quad-Mount Apocalypse Missile Launcher"
        TreeNode101.Name = "Node17"
        TreeNode101.Text = "Emperator"
        TreeNode102.Name = "Node0"
        TreeNode102.Text = "Weaponry Configurations"
        TreeNode103.Name = "Node14"
        TreeNode103.Text = "Greyhound Chassis"
        TreeNode104.Name = "Node15"
        TreeNode104.Text = "Mastiff Chassis"
        TreeNode105.Name = "Node16"
        TreeNode105.Text = "Chulainn Chassis"
        TreeNode106.Name = "Node9"
        TreeNode106.Text = "Warhound"
        TreeNode107.Name = "Node36"
        TreeNode107.Text = "Gladiator Chassis"
        TreeNode108.Name = "Node37"
        TreeNode108.Text = "Sentinel Chassis"
        TreeNode109.Name = "Node38"
        TreeNode109.Text = "Interceptor Chassis"
        TreeNode110.Name = "Node10"
        TreeNode110.Text = "Reaver"
        TreeNode111.Name = "Node39"
        TreeNode111.Text = "Barrage Chassis"
        TreeNode112.Name = "Node40"
        TreeNode112.Text = "Astraea Chassis"
        TreeNode113.Name = "Node41"
        TreeNode113.Text = "Corona Chassis"
        TreeNode114.Name = "Node11"
        TreeNode114.Text = "Warbringer"
        TreeNode115.Name = "Node42"
        TreeNode115.Text = "Solais Ira Chassis"
        TreeNode116.Name = "Node43"
        TreeNode116.Text = "Panopticon Chassis"
        TreeNode117.Name = "Node44"
        TreeNode117.Text = "Thronebreaker Chassis"
        TreeNode118.Name = "Node12"
        TreeNode118.Text = "Warlord"
        TreeNode119.Name = "Node45"
        TreeNode119.Text = "Paladin Chassis"
        TreeNode120.Name = "Node46"
        TreeNode120.Text = "Skyshock Chassis"
        TreeNode121.Name = "Node47"
        TreeNode121.Text = "Xenia Chassis"
        TreeNode122.Name = "Node2"
        TreeNode122.Text = "Challenger Chassis"
        TreeNode123.Name = "Node13"
        TreeNode123.Text = "Emperator"
        TreeNode124.Name = "Node1"
        TreeNode124.Text = "Equipment Configurations"
        Me.TreeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode102, TreeNode124})
        Me.TreeView1.Size = New System.Drawing.Size(391, 147)
        Me.TreeView1.TabIndex = 0
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(106, 358)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(125, 29)
        Me.ProgressBar1.TabIndex = 76
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(141, 335)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(51, 20)
        Me.Label34.TabIndex = 77
        Me.Label34.Text = "Speed"
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(106, 413)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(125, 33)
        Me.ProgressBar2.TabIndex = 78
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(133, 390)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(59, 20)
        Me.Label35.TabIndex = 79
        Me.Label35.Text = "Armour"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(131, 456)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(61, 20)
        Me.Label36.TabIndex = 81
        Me.Label36.Text = "Label36"
        '
        'TitanOneErrorBox
        '
        Me.TitanOneErrorBox.Location = New System.Drawing.Point(106, 479)
        Me.TitanOneErrorBox.Name = "TitanOneErrorBox"
        Me.TitanOneErrorBox.Size = New System.Drawing.Size(125, 27)
        Me.TitanOneErrorBox.TabIndex = 100
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Location = New System.Drawing.Point(257, 12)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(422, 203)
        Me.TabControl2.TabIndex = 101
        '
        'TabPage6
        '
        Me.TabPage6.AutoScroll = True
        Me.TabPage6.AutoScrollMargin = New System.Drawing.Size(0, 100)
        Me.TabPage6.Controls.Add(Me.TableLayoutPanel6)
        Me.TabPage6.Controls.Add(Me.TableLayoutPanel5)
        Me.TabPage6.Controls.Add(Me.TableLayoutPanel4)
        Me.TabPage6.Controls.Add(Me.TableLayoutPanel2)
        Me.TabPage6.Controls.Add(Me.TableLayoutPanel1)
        Me.TabPage6.Controls.Add(Me.TableLayoutPanel3)
        Me.TabPage6.Location = New System.Drawing.Point(4, 29)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(414, 170)
        Me.TabPage6.TabIndex = 0
        Me.TabPage6.Text = "Your Titan Formations"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.ColumnCount = 2
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.Label77, 0, 8)
        Me.TableLayoutPanel6.Controls.Add(Me.Label78, 0, 9)
        Me.TableLayoutPanel6.Controls.Add(Me.Label79, 0, 7)
        Me.TableLayoutPanel6.Controls.Add(Me.Label80, 0, 6)
        Me.TableLayoutPanel6.Controls.Add(Me.TextBox42, 1, 4)
        Me.TableLayoutPanel6.Controls.Add(Me.TextBox43, 1, 3)
        Me.TableLayoutPanel6.Controls.Add(Me.TextBox44, 1, 2)
        Me.TableLayoutPanel6.Controls.Add(Me.TextBox45, 1, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.Label81, 0, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.Label82, 0, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.TextBox46, 1, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.Label83, 0, 2)
        Me.TableLayoutPanel6.Controls.Add(Me.Label84, 0, 3)
        Me.TableLayoutPanel6.Controls.Add(Me.Label85, 0, 4)
        Me.TableLayoutPanel6.Controls.Add(Me.TextBox47, 1, 5)
        Me.TableLayoutPanel6.Controls.Add(Me.Label86, 0, 5)
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(3, 2079)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 10
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(387, 429)
        Me.TableLayoutPanel6.TabIndex = 134
        '
        'Label77
        '
        Me.Label77.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(66, 347)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(61, 20)
        Me.Label77.TabIndex = 120
        Me.Label77.Text = "Label77"
        Me.Label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label78
        '
        Me.Label78.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(66, 393)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(61, 20)
        Me.Label78.TabIndex = 121
        Me.Label78.Text = "Label78"
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label79
        '
        Me.Label79.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(66, 305)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(61, 20)
        Me.Label79.TabIndex = 121
        Me.Label79.Text = "Label79"
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label80
        '
        Me.Label80.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(66, 263)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(61, 20)
        Me.Label80.TabIndex = 122
        Me.Label80.Text = "Label80"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(196, 171)
        Me.TextBox42.Multiline = True
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(188, 32)
        Me.TextBox42.TabIndex = 129
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(196, 129)
        Me.TextBox43.Multiline = True
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(188, 32)
        Me.TextBox43.TabIndex = 128
        '
        'TextBox44
        '
        Me.TextBox44.Location = New System.Drawing.Point(196, 87)
        Me.TextBox44.Multiline = True
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(188, 32)
        Me.TextBox44.TabIndex = 127
        '
        'TextBox45
        '
        Me.TextBox45.Location = New System.Drawing.Point(196, 45)
        Me.TextBox45.Multiline = True
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(188, 32)
        Me.TextBox45.TabIndex = 126
        '
        'Label81
        '
        Me.Label81.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(38, 11)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(117, 20)
        Me.Label81.TabIndex = 1
        Me.Label81.Text = "Titan One Name"
        Me.Label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label82
        '
        Me.Label82.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(42, 53)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(108, 20)
        Me.Label82.TabIndex = 121
        Me.Label82.Text = "Titan One Type"
        Me.Label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox46
        '
        Me.TextBox46.Location = New System.Drawing.Point(196, 3)
        Me.TextBox46.Multiline = True
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(188, 32)
        Me.TextBox46.TabIndex = 0
        '
        'Label83
        '
        Me.Label83.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(46, 95)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(100, 20)
        Me.Label83.TabIndex = 120
        Me.Label83.Text = "Titan Subtype"
        Me.Label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label84
        '
        Me.Label84.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label84.AutoSize = True
        Me.Label84.Location = New System.Drawing.Point(66, 137)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(61, 20)
        Me.Label84.TabIndex = 124
        Me.Label84.Text = "Label84"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label85
        '
        Me.Label85.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label85.AutoSize = True
        Me.Label85.Location = New System.Drawing.Point(34, 179)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(125, 20)
        Me.Label85.TabIndex = 125
        Me.Label85.Text = "Left Arm Weapon"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox47
        '
        Me.TextBox47.Location = New System.Drawing.Point(196, 213)
        Me.TextBox47.Multiline = True
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(188, 32)
        Me.TextBox47.TabIndex = 130
        '
        'Label86
        '
        Me.Label86.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label86.AutoSize = True
        Me.Label86.Location = New System.Drawing.Point(66, 221)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(61, 20)
        Me.Label86.TabIndex = 123
        Me.Label86.Text = "Label86"
        Me.Label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.ColumnCount = 2
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Label67, 0, 8)
        Me.TableLayoutPanel5.Controls.Add(Me.Label68, 0, 9)
        Me.TableLayoutPanel5.Controls.Add(Me.Label69, 0, 7)
        Me.TableLayoutPanel5.Controls.Add(Me.Label70, 0, 6)
        Me.TableLayoutPanel5.Controls.Add(Me.TextBox36, 1, 4)
        Me.TableLayoutPanel5.Controls.Add(Me.TextBox37, 1, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.TextBox38, 1, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.TextBox39, 1, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label71, 0, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label72, 0, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.TextBox40, 1, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label73, 0, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.Label74, 0, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.Label75, 0, 4)
        Me.TableLayoutPanel5.Controls.Add(Me.TextBox41, 1, 5)
        Me.TableLayoutPanel5.Controls.Add(Me.Label76, 0, 5)
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(3, 1694)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 10
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(387, 382)
        Me.TableLayoutPanel5.TabIndex = 133
        '
        'Label67
        '
        Me.Label67.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(66, 313)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(61, 20)
        Me.Label67.TabIndex = 120
        Me.Label67.Text = "Label67"
        Me.Label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label68
        '
        Me.Label68.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(66, 352)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(61, 20)
        Me.Label68.TabIndex = 121
        Me.Label68.Text = "Label68"
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label69
        '
        Me.Label69.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(66, 275)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(61, 20)
        Me.Label69.TabIndex = 121
        Me.Label69.Text = "Label69"
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label70
        '
        Me.Label70.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(66, 237)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(61, 20)
        Me.Label70.TabIndex = 122
        Me.Label70.Text = "Label70"
        Me.Label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(196, 155)
        Me.TextBox36.Multiline = True
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(188, 32)
        Me.TextBox36.TabIndex = 129
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(196, 117)
        Me.TextBox37.Multiline = True
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(188, 32)
        Me.TextBox37.TabIndex = 128
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(196, 79)
        Me.TextBox38.Multiline = True
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(188, 32)
        Me.TextBox38.TabIndex = 127
        '
        'TextBox39
        '
        Me.TextBox39.Location = New System.Drawing.Point(196, 41)
        Me.TextBox39.Multiline = True
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(188, 32)
        Me.TextBox39.TabIndex = 126
        '
        'Label71
        '
        Me.Label71.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(38, 9)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(117, 20)
        Me.Label71.TabIndex = 1
        Me.Label71.Text = "Titan One Name"
        Me.Label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label72
        '
        Me.Label72.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(42, 47)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(108, 20)
        Me.Label72.TabIndex = 121
        Me.Label72.Text = "Titan One Type"
        Me.Label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox40
        '
        Me.TextBox40.Location = New System.Drawing.Point(196, 3)
        Me.TextBox40.Multiline = True
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(188, 32)
        Me.TextBox40.TabIndex = 0
        '
        'Label73
        '
        Me.Label73.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(46, 85)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(100, 20)
        Me.Label73.TabIndex = 120
        Me.Label73.Text = "Titan Subtype"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label74
        '
        Me.Label74.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(66, 123)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(61, 20)
        Me.Label74.TabIndex = 124
        Me.Label74.Text = "Label74"
        Me.Label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label75
        '
        Me.Label75.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(34, 161)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(125, 20)
        Me.Label75.TabIndex = 125
        Me.Label75.Text = "Left Arm Weapon"
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox41
        '
        Me.TextBox41.Location = New System.Drawing.Point(196, 193)
        Me.TextBox41.Multiline = True
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(188, 32)
        Me.TextBox41.TabIndex = 130
        '
        'Label76
        '
        Me.Label76.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(66, 199)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(61, 20)
        Me.Label76.TabIndex = 123
        Me.Label76.Text = "Label76"
        Me.Label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label57, 0, 8)
        Me.TableLayoutPanel4.Controls.Add(Me.Label58, 0, 9)
        Me.TableLayoutPanel4.Controls.Add(Me.Label59, 0, 7)
        Me.TableLayoutPanel4.Controls.Add(Me.Label60, 0, 6)
        Me.TableLayoutPanel4.Controls.Add(Me.TextBox30, 1, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.TextBox31, 1, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.TextBox32, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.TextBox33, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label61, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label62, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.TextBox34, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label63, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label64, 0, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Label65, 0, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.TextBox35, 1, 5)
        Me.TableLayoutPanel4.Controls.Add(Me.Label66, 0, 5)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(3, 1306)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 10
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(387, 386)
        Me.TableLayoutPanel4.TabIndex = 132
        '
        'Label57
        '
        Me.Label57.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(66, 313)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(61, 20)
        Me.Label57.TabIndex = 120
        Me.Label57.Text = "Label57"
        Me.Label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label58
        '
        Me.Label58.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(66, 354)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(61, 20)
        Me.Label58.TabIndex = 121
        Me.Label58.Text = "Label58"
        Me.Label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label59
        '
        Me.Label59.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(66, 275)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(61, 20)
        Me.Label59.TabIndex = 121
        Me.Label59.Text = "Label59"
        Me.Label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label60
        '
        Me.Label60.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(66, 237)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(61, 20)
        Me.Label60.TabIndex = 122
        Me.Label60.Text = "Label60"
        Me.Label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(196, 155)
        Me.TextBox30.Multiline = True
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(188, 32)
        Me.TextBox30.TabIndex = 129
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(196, 117)
        Me.TextBox31.Multiline = True
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(188, 32)
        Me.TextBox31.TabIndex = 128
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(196, 79)
        Me.TextBox32.Multiline = True
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(188, 32)
        Me.TextBox32.TabIndex = 127
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(196, 41)
        Me.TextBox33.Multiline = True
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(188, 32)
        Me.TextBox33.TabIndex = 126
        '
        'Label61
        '
        Me.Label61.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(38, 9)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(117, 20)
        Me.Label61.TabIndex = 1
        Me.Label61.Text = "Titan One Name"
        Me.Label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label62
        '
        Me.Label62.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(42, 47)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(108, 20)
        Me.Label62.TabIndex = 121
        Me.Label62.Text = "Titan One Type"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(196, 3)
        Me.TextBox34.Multiline = True
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(188, 32)
        Me.TextBox34.TabIndex = 0
        '
        'Label63
        '
        Me.Label63.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(46, 85)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(100, 20)
        Me.Label63.TabIndex = 120
        Me.Label63.Text = "Titan Subtype"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label64
        '
        Me.Label64.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(66, 123)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(61, 20)
        Me.Label64.TabIndex = 124
        Me.Label64.Text = "Label64"
        Me.Label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label65
        '
        Me.Label65.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(34, 161)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(125, 20)
        Me.Label65.TabIndex = 125
        Me.Label65.Text = "Left Arm Weapon"
        Me.Label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(196, 193)
        Me.TextBox35.Multiline = True
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(188, 32)
        Me.TextBox35.TabIndex = 130
        '
        'Label66
        '
        Me.Label66.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(66, 199)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(61, 20)
        Me.Label66.TabIndex = 123
        Me.Label66.Text = "Label66"
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox51, 1, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox50, 1, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox49, 1, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.Label37, 0, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.Label39, 0, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.Label40, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox12, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox19, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox20, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label41, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label42, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox22, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label43, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label44, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label45, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox23, 1, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label46, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox48, 1, 9)
        Me.TableLayoutPanel2.Controls.Add(Me.Label38, 0, 9)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 389)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 10
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(387, 448)
        Me.TableLayoutPanel2.TabIndex = 131
        '
        'TextBox51
        '
        Me.TextBox51.Location = New System.Drawing.Point(196, 355)
        Me.TextBox51.Multiline = True
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(188, 32)
        Me.TextBox51.TabIndex = 131
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(196, 311)
        Me.TextBox50.Multiline = True
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(188, 32)
        Me.TextBox50.TabIndex = 132
        '
        'TextBox49
        '
        Me.TextBox49.Location = New System.Drawing.Point(196, 267)
        Me.TextBox49.Multiline = True
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(188, 32)
        Me.TextBox49.TabIndex = 131
        '
        'Label37
        '
        Me.Label37.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(12, 364)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(169, 20)
        Me.Label37.TabIndex = 120
        Me.Label37.Text = "Support Equipment One"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label39
        '
        Me.Label39.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(18, 320)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(157, 20)
        Me.Label39.TabIndex = 121
        Me.Label39.Text = "Right Carapace Mount"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label40
        '
        Me.Label40.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(23, 276)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(147, 20)
        Me.Label40.TabIndex = 122
        Me.Label40.Text = "Left Carapace Mount"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(196, 179)
        Me.TextBox12.Multiline = True
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(188, 32)
        Me.TextBox12.TabIndex = 129
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(196, 135)
        Me.TextBox19.Multiline = True
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(188, 32)
        Me.TextBox19.TabIndex = 128
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(196, 91)
        Me.TextBox20.Multiline = True
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(188, 32)
        Me.TextBox20.TabIndex = 127
        '
        'completedOneType
        '
        Me.completedOneType.Location = New System.Drawing.Point(199, 41)
        Me.completedOneType.Multiline = True
        Me.completedOneType.Name = "completedOneType"
        Me.completedOneType.Size = New System.Drawing.Size(188, 32)
        Me.completedOneType.TabIndex = 126
        '
        'Label41
        '
        Me.Label41.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(38, 12)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(117, 20)
        Me.Label41.TabIndex = 1
        Me.Label41.Text = "Titan Two Name"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label42
        '
        Me.Label42.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(56, 56)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(81, 20)
        Me.Label42.TabIndex = 121
        Me.Label42.Text = "Titan  Type"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(196, 3)
        Me.TextBox22.Multiline = True
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(188, 32)
        Me.TextBox22.TabIndex = 0
        '
        'Label43
        '
        Me.Label43.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(46, 100)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(100, 20)
        Me.Label43.TabIndex = 120
        Me.Label43.Text = "Titan Subtype"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label44
        '
        Me.Label44.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(34, 144)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(125, 20)
        Me.Label44.TabIndex = 124
        Me.Label44.Text = "Left Arm Weapon"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label45
        '
        Me.Label45.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(29, 188)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(135, 20)
        Me.Label45.TabIndex = 125
        Me.Label45.Text = "Right Arm Weapon"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(196, 223)
        Me.TextBox23.Multiline = True
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(188, 32)
        Me.TextBox23.TabIndex = 130
        '
        'Label46
        '
        Me.Label46.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(9, 232)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(174, 20)
        Me.Label46.TabIndex = 123
        Me.Label46.Text = "Cenrtral Carapace Mount"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox48
        '
        Me.TextBox48.Location = New System.Drawing.Point(196, 399)
        Me.TextBox48.Multiline = True
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(188, 32)
        Me.TextBox48.TabIndex = 131
        '
        'Label38
        '
        Me.Label38.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(12, 412)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(169, 20)
        Me.Label38.TabIndex = 121
        Me.Label38.Text = "Support Equipment Two"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.CompletedOneSupportTwo, 1, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.CompleteOneSupportOne, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.CompletedOneRMount, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.CompletedOneLMount, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label24, 0, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label30, 0, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label25, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label26, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.CompletedOneRightArm, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.completedOneType, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.CompletedOneLeftArm, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.CompletedOneSubtype, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.CompletedOneName, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label22, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label28, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label29, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.CompletedOneCMount, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label27, 0, 5)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 10
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(393, 386)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'CompletedOneSupportTwo
        '
        Me.CompletedOneSupportTwo.Location = New System.Drawing.Point(199, 345)
        Me.CompletedOneSupportTwo.Multiline = True
        Me.CompletedOneSupportTwo.Name = "CompletedOneSupportTwo"
        Me.CompletedOneSupportTwo.Size = New System.Drawing.Size(191, 32)
        Me.CompletedOneSupportTwo.TabIndex = 131
        '
        'CompleteOneSupportOne
        '
        Me.CompleteOneSupportOne.Location = New System.Drawing.Point(199, 307)
        Me.CompleteOneSupportOne.Multiline = True
        Me.CompleteOneSupportOne.Name = "CompleteOneSupportOne"
        Me.CompleteOneSupportOne.Size = New System.Drawing.Size(191, 32)
        Me.CompleteOneSupportOne.TabIndex = 132
        '
        'CompletedOneRMount
        '
        Me.CompletedOneRMount.Location = New System.Drawing.Point(199, 269)
        Me.CompletedOneRMount.Multiline = True
        Me.CompletedOneRMount.Name = "CompletedOneRMount"
        Me.CompletedOneRMount.Size = New System.Drawing.Size(191, 32)
        Me.CompletedOneRMount.TabIndex = 133
        '
        'CompletedOneLMount
        '
        Me.CompletedOneLMount.Location = New System.Drawing.Point(199, 231)
        Me.CompletedOneLMount.Multiline = True
        Me.CompletedOneLMount.Name = "CompletedOneLMount"
        Me.CompletedOneLMount.Size = New System.Drawing.Size(191, 32)
        Me.CompletedOneLMount.TabIndex = 134
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(13, 313)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(169, 20)
        Me.Label24.TabIndex = 120
        Me.Label24.Text = "Support Equipment One"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label30
        '
        Me.Label30.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(13, 354)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(169, 20)
        Me.Label30.TabIndex = 121
        Me.Label30.Text = "Support Equipment Two"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(19, 275)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(157, 20)
        Me.Label25.TabIndex = 121
        Me.Label25.Text = "Right Carapace Mount"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(24, 237)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(147, 20)
        Me.Label26.TabIndex = 122
        Me.Label26.Text = "Left Carapace Mount"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CompletedOneRightArm
        '
        Me.CompletedOneRightArm.Location = New System.Drawing.Point(199, 155)
        Me.CompletedOneRightArm.Multiline = True
        Me.CompletedOneRightArm.Name = "CompletedOneRightArm"
        Me.CompletedOneRightArm.Size = New System.Drawing.Size(191, 32)
        Me.CompletedOneRightArm.TabIndex = 129
        '
        'CompletedOneLeftArm
        '
        Me.CompletedOneLeftArm.Location = New System.Drawing.Point(199, 117)
        Me.CompletedOneLeftArm.Multiline = True
        Me.CompletedOneLeftArm.Name = "CompletedOneLeftArm"
        Me.CompletedOneLeftArm.Size = New System.Drawing.Size(191, 32)
        Me.CompletedOneLeftArm.TabIndex = 128
        '
        'CompletedOneSubtype
        '
        Me.CompletedOneSubtype.Location = New System.Drawing.Point(199, 79)
        Me.CompletedOneSubtype.Multiline = True
        Me.CompletedOneSubtype.Name = "CompletedOneSubtype"
        Me.CompletedOneSubtype.Size = New System.Drawing.Size(191, 32)
        Me.CompletedOneSubtype.TabIndex = 127
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(39, 9)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(117, 20)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Titan One Name"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(59, 47)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(77, 20)
        Me.Label23.TabIndex = 121
        Me.Label23.Text = "Titan Type"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CompletedOneName
        '
        Me.CompletedOneName.Location = New System.Drawing.Point(199, 3)
        Me.CompletedOneName.Multiline = True
        Me.CompletedOneName.Name = "CompletedOneName"
        Me.CompletedOneName.Size = New System.Drawing.Size(191, 32)
        Me.CompletedOneName.TabIndex = 0
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(48, 85)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(100, 20)
        Me.Label22.TabIndex = 120
        Me.Label22.Text = "Titan Subtype"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(35, 123)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(125, 20)
        Me.Label28.TabIndex = 124
        Me.Label28.Text = "Left Arm Weapon"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(30, 161)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(135, 20)
        Me.Label29.TabIndex = 125
        Me.Label29.Text = "Right Arm Weapon"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CompletedOneCMount
        '
        Me.CompletedOneCMount.Location = New System.Drawing.Point(199, 193)
        Me.CompletedOneCMount.Multiline = True
        Me.CompletedOneCMount.Name = "CompletedOneCMount"
        Me.CompletedOneCMount.Size = New System.Drawing.Size(191, 32)
        Me.CompletedOneCMount.TabIndex = 130
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(15, 199)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(165, 20)
        Me.Label27.TabIndex = 123
        Me.Label27.Text = "Center Carapace Mount"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox6, 1, 9)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox8, 1, 8)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox9, 1, 7)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox52, 1, 6)
        Me.TableLayoutPanel3.Controls.Add(Me.Label47, 0, 8)
        Me.TableLayoutPanel3.Controls.Add(Me.Label48, 0, 9)
        Me.TableLayoutPanel3.Controls.Add(Me.Label49, 0, 7)
        Me.TableLayoutPanel3.Controls.Add(Me.Label50, 0, 6)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox24, 1, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox25, 1, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox26, 1, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox27, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label51, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label52, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox28, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label53, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Label54, 0, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.Label55, 0, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox29, 1, 5)
        Me.TableLayoutPanel3.Controls.Add(Me.Label56, 0, 5)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 847)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 10
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(384, 453)
        Me.TableLayoutPanel3.TabIndex = 131
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(195, 408)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(186, 32)
        Me.TextBox6.TabIndex = 132
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(195, 363)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(186, 32)
        Me.TextBox8.TabIndex = 133
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(195, 318)
        Me.TextBox9.Multiline = True
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(186, 32)
        Me.TextBox9.TabIndex = 134
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(195, 273)
        Me.TextBox52.Multiline = True
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(186, 32)
        Me.TextBox52.TabIndex = 131
        '
        'Label47
        '
        Me.Label47.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(11, 372)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(169, 20)
        Me.Label47.TabIndex = 120
        Me.Label47.Text = "Support Equipment One"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label48
        '
        Me.Label48.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(11, 419)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(169, 20)
        Me.Label48.TabIndex = 121
        Me.Label48.Text = "Support Equipment Two"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label49
        '
        Me.Label49.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(17, 327)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(157, 20)
        Me.Label49.TabIndex = 121
        Me.Label49.Text = "Right Carapace Mount"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label50
        '
        Me.Label50.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(22, 282)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(147, 20)
        Me.Label50.TabIndex = 122
        Me.Label50.Text = "Left Carapace Mount"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(195, 183)
        Me.TextBox24.Multiline = True
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(186, 32)
        Me.TextBox24.TabIndex = 129
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(195, 138)
        Me.TextBox25.Multiline = True
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(186, 32)
        Me.TextBox25.TabIndex = 128
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(195, 93)
        Me.TextBox26.Multiline = True
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(186, 32)
        Me.TextBox26.TabIndex = 127
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(195, 48)
        Me.TextBox27.Multiline = True
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(186, 32)
        Me.TextBox27.TabIndex = 126
        '
        'Label51
        '
        Me.Label51.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(32, 12)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(127, 20)
        Me.Label51.TabIndex = 1
        Me.Label51.Text = "Titan Three Name"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label52
        '
        Me.Label52.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(57, 57)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(77, 20)
        Me.Label52.TabIndex = 121
        Me.Label52.Text = "Titan Type"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(195, 3)
        Me.TextBox28.Multiline = True
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(186, 32)
        Me.TextBox28.TabIndex = 0
        '
        'Label53
        '
        Me.Label53.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(46, 102)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(100, 20)
        Me.Label53.TabIndex = 120
        Me.Label53.Text = "Titan Subtype"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label54
        '
        Me.Label54.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(33, 147)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(125, 20)
        Me.Label54.TabIndex = 124
        Me.Label54.Text = "Left Arm Weapon"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label55
        '
        Me.Label55.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(28, 192)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(135, 20)
        Me.Label55.TabIndex = 125
        Me.Label55.Text = "Right Arm Weapon"
        Me.Label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(195, 228)
        Me.TextBox29.Multiline = True
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(186, 32)
        Me.TextBox29.TabIndex = 130
        '
        'Label56
        '
        Me.Label56.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(11, 237)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(169, 20)
        Me.Label56.TabIndex = 123
        Me.Label56.Text = "Central Carapace Mount"
        Me.Label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Vanguard", "Rear-Guard", "Anti-Infantry", "Anti-Vehicle", "Anti-Titan", "Anti-Air", "Anti-Building", "Annihilator"})
        Me.ComboBox1.Location = New System.Drawing.Point(106, 301)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(125, 28)
        Me.ComboBox1.TabIndex = 102
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(5, 294)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 20)
        Me.Label7.TabIndex = 103
        Me.Label7.Text = "Formation"
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage2)
        Me.TabControl3.Location = New System.Drawing.Point(257, 217)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(422, 203)
        Me.TabControl3.TabIndex = 104
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(414, 170)
        Me.TabPage2.TabIndex = 0
        Me.TabPage2.Text = "Enemy Formation"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(975, 468)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(94, 29)
        Me.Button2.TabIndex = 105
        Me.Button2.Text = "Compare"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(716, 302)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(205, 20)
        Me.Label8.TabIndex = 106
        Me.Label8.Text = "Enemy Guardsmen Equivelent"
        '
        'ProgressBar3
        '
        Me.ProgressBar3.Location = New System.Drawing.Point(927, 188)
        Me.ProgressBar3.Name = "ProgressBar3"
        Me.ProgressBar3.Size = New System.Drawing.Size(125, 29)
        Me.ProgressBar3.TabIndex = 107
        '
        'ProgressBar4
        '
        Me.ProgressBar4.Location = New System.Drawing.Point(927, 217)
        Me.ProgressBar4.Name = "ProgressBar4"
        Me.ProgressBar4.Size = New System.Drawing.Size(125, 29)
        Me.ProgressBar4.TabIndex = 108
        '
        'ProgressBar5
        '
        Me.ProgressBar5.Location = New System.Drawing.Point(927, 246)
        Me.ProgressBar5.Name = "ProgressBar5"
        Me.ProgressBar5.Size = New System.Drawing.Size(125, 29)
        Me.ProgressBar5.TabIndex = 109
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(932, 399)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(185, 27)
        Me.TextBox4.TabIndex = 110
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(932, 432)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(185, 27)
        Me.TextBox5.TabIndex = 111
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(701, 335)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(220, 20)
        Me.Label9.TabIndex = 112
        Me.Label9.Text = "Enemy Space Marine Equivelent"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(744, 369)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(177, 20)
        Me.Label10.TabIndex = 113
        Me.Label10.Text = "Enemy Vehicle Equivelent"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(727, 402)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(194, 20)
        Me.Label11.TabIndex = 114
        Me.Label11.Text = "Enemy Ordinatus Equivelent"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(758, 435)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(163, 20)
        Me.Label12.TabIndex = 115
        Me.Label12.Text = "Enemy Titan Equivelent"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(88, 597)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(1029, 120)
        Me.RichTextBox1.TabIndex = 116
        Me.RichTextBox1.Text = ""
        '
        'comComponentBox
        '
        Me.comComponentBox.FormattingEnabled = True
        Me.comComponentBox.Items.AddRange(New Object() {"Apocalypse Missile Launcher", "Belicosa Volcano Cannon", "Doomstrike Missile Launcher", "Gatling Blaster", "Hellstorm Cannon", "Inferno Cannon", "Kalidan Linear Accelerator", "Macro Gatling Blaster", "Melta Cannon", "Melta-Chainfist", "Morai Quake Cannon", "Nemesis Kalidan Linear Accelerator", "Nemesis Quake Cannon", "Plasma Annihilator", "Plasma Blastgun", "Power Galatine", "Plasma Immolator", "Turbo-Laser Destructor", "Vengeance Lance", "Volcano Cannon", "Vulcan Megabolter"})
        Me.comComponentBox.Location = New System.Drawing.Point(384, 528)
        Me.comComponentBox.Name = "comComponentBox"
        Me.comComponentBox.Size = New System.Drawing.Size(151, 28)
        Me.comComponentBox.TabIndex = 117
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(384, 562)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(151, 29)
        Me.Button4.TabIndex = 118
        Me.Button4.Text = "Button4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(230, 531)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(148, 20)
        Me.Label19.TabIndex = 119
        Me.Label19.Text = "Selected Component"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(701, 217)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(61, 20)
        Me.Label21.TabIndex = 15
        Me.Label21.Text = "Label21"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Location = New System.Drawing.Point(10, 158)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(49, 20)
        Me.Label87.TabIndex = 120
        Me.Label87.Text = "Cback"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(257, 442)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(125, 29)
        Me.Button5.TabIndex = 122
        Me.Button5.Text = "Accept"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'combtitanType
        '
        Me.combtitanType.FormattingEnabled = True
        Me.combtitanType.Items.AddRange(New Object() {"Warhound", "Reaver", "Warbringer", "Warlord", "Emperator"})
        Me.combtitanType.Location = New System.Drawing.Point(106, 41)
        Me.combtitanType.Name = "combtitanType"
        Me.combtitanType.Size = New System.Drawing.Size(125, 28)
        Me.combtitanType.TabIndex = 123
        '
        'combTitanLarm
        '
        Me.combTitanLarm.FormattingEnabled = True
        Me.combTitanLarm.Location = New System.Drawing.Point(106, 80)
        Me.combTitanLarm.Name = "combTitanLarm"
        Me.combTitanLarm.Size = New System.Drawing.Size(125, 28)
        Me.combTitanLarm.TabIndex = 124
        '
        'combTitanRArm
        '
        Me.combTitanRArm.FormattingEnabled = True
        Me.combTitanRArm.Location = New System.Drawing.Point(106, 120)
        Me.combTitanRArm.Name = "combTitanRArm"
        Me.combTitanRArm.Size = New System.Drawing.Size(125, 28)
        Me.combTitanRArm.TabIndex = 125
        '
        'combTitanRBack
        '
        Me.combTitanRBack.FormattingEnabled = True
        Me.combTitanRBack.Location = New System.Drawing.Point(106, 223)
        Me.combTitanRBack.Name = "combTitanRBack"
        Me.combTitanRBack.Size = New System.Drawing.Size(125, 28)
        Me.combTitanRBack.TabIndex = 126
        '
        'comboTitanLBack
        '
        Me.comboTitanLBack.FormattingEnabled = True
        Me.comboTitanLBack.Location = New System.Drawing.Point(106, 192)
        Me.comboTitanLBack.Name = "comboTitanLBack"
        Me.comboTitanLBack.Size = New System.Drawing.Size(125, 28)
        Me.comboTitanLBack.TabIndex = 127
        '
        'combTitanCBack
        '
        Me.combTitanCBack.FormattingEnabled = True
        Me.combTitanCBack.Location = New System.Drawing.Point(106, 155)
        Me.combTitanCBack.Name = "combTitanCBack"
        Me.combTitanCBack.Size = New System.Drawing.Size(125, 28)
        Me.combTitanCBack.TabIndex = 128
        '
        'combTitanSubtype
        '
        Me.combTitanSubtype.FormattingEnabled = True
        Me.combTitanSubtype.Location = New System.Drawing.Point(106, 261)
        Me.combTitanSubtype.Name = "combTitanSubtype"
        Me.combTitanSubtype.Size = New System.Drawing.Size(125, 28)
        Me.combTitanSubtype.TabIndex = 129
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1159, 752)
        Me.Controls.Add(Me.combTitanSubtype)
        Me.Controls.Add(Me.combTitanCBack)
        Me.Controls.Add(Me.comboTitanLBack)
        Me.Controls.Add(Me.combTitanRBack)
        Me.Controls.Add(Me.combTitanRArm)
        Me.Controls.Add(Me.combTitanLarm)
        Me.Controls.Add(Me.combtitanType)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Label87)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.comComponentBox)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.ProgressBar5)
        Me.Controls.Add(Me.ProgressBar4)
        Me.Controls.Add(Me.ProgressBar3)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TabControl3)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.TitanOneErrorBox)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.ProgressBar2)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.titanName)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Titan Maniple Power Rating"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.TableLayoutPanel6.PerformLayout()
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.TabControl3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents titanName As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TreeView1 As TreeView
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents Label34 As Label
    Friend WithEvents ProgressBar2 As ProgressBar
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents TitanOneErrorBox As TextBox
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TabControl3 As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Button2 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents ProgressBar3 As ProgressBar
    Friend WithEvents ProgressBar4 As ProgressBar
    Friend WithEvents ProgressBar5 As ProgressBar
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents comComponentBox As ComboBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents CompletedOneCMount As TextBox
    Friend WithEvents CompletedOneRightArm As TextBox
    Friend WithEvents CompletedOneLeftArm As TextBox
    Friend WithEvents CompletedOneSubtype As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents CompletedOneName As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Label67 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents TextBox36 As TextBox
    Friend WithEvents TextBox37 As TextBox
    Friend WithEvents TextBox38 As TextBox
    Friend WithEvents TextBox39 As TextBox
    Friend WithEvents Label71 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents TextBox40 As TextBox
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents TextBox41 As TextBox
    Friend WithEvents Label76 As Label
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents Label57 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents TextBox30 As TextBox
    Friend WithEvents TextBox31 As TextBox
    Friend WithEvents TextBox32 As TextBox
    Friend WithEvents TextBox33 As TextBox
    Friend WithEvents Label61 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents TextBox34 As TextBox
    Friend WithEvents Label63 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents TextBox35 As TextBox
    Friend WithEvents Label66 As Label
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox19 As TextBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents completedOneType As TextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents Label46 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents TextBox24 As TextBox
    Friend WithEvents TextBox25 As TextBox
    Friend WithEvents TextBox26 As TextBox
    Friend WithEvents TextBox27 As TextBox
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents TextBox29 As TextBox
    Friend WithEvents Label56 As Label
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents Label77 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents TextBox42 As TextBox
    Friend WithEvents TextBox43 As TextBox
    Friend WithEvents TextBox44 As TextBox
    Friend WithEvents TextBox45 As TextBox
    Friend WithEvents Label81 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents TextBox46 As TextBox
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents TextBox47 As TextBox
    Friend WithEvents Label86 As Label
    Friend WithEvents TextBox51 As TextBox
    Friend WithEvents TextBox50 As TextBox
    Friend WithEvents TextBox49 As TextBox
    Friend WithEvents TextBox48 As TextBox
    Friend WithEvents TextBox52 As TextBox
    Friend WithEvents CompletedOneSupportTwo As TextBox
    Friend WithEvents CompleteOneSupportOne As TextBox
    Friend WithEvents CompletedOneRMount As TextBox
    Friend WithEvents CompletedOneLMount As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Label87 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents combtitanType As ComboBox
    Friend WithEvents combTitanLarm As ComboBox
    Friend WithEvents combTitanRArm As ComboBox
    Friend WithEvents combTitanRBack As ComboBox
    Friend WithEvents comboTitanLBack As ComboBox
    Friend WithEvents combTitanCBack As ComboBox
    Friend WithEvents combTitanSubtype As ComboBox
End Class
